import React from 'react';

import { StatusBar } from 'expo-status-bar';
import { FlatList,Image, StyleSheet, Text, View , Button, TextInput, ScrollView} from 'react-native';

/*
const imagePath = require("./assets/favicon.png")
const data = [{ idi: '1', name: 'Εστιατόριο A' ,extra:'one'}, 
  { idi: '3', name: 'Εστιατόριο B', extra:'two' }, 
  { idi: '4', name: 'Εστιατόριο B', extra:'two' }, 
  { idi: '5', name: 'Εστιατόριο B', extra:'two' }
  , { idi: '6', name: 'Εστιατόριο B', extra:'two' }
  , { idi: '7', name: 'Εστιατόριο B', extra:'two' }
  , { idi: '8', name: 'Εστιατόριο B', extra:'two' }];
export default function App() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#f0f0f0' }}>
      
      <Image source={require("./assets/favicon.png")} style={{ width: 100, height: 100 }} />
      <Text style={{ fontSize: 20, fontWeight: 'bold', color: 'blue' }}>
  Καλώς ήρθατε στην εφαρμογή μας!
</Text>
<TextInput
  style={{ height: 40, borderColor: 'gray', borderWidth: 1, paddingHorizontal: 10 }}
  placeholder="Εισάγετε το όνομά σας"/>


<Button title="Πατήστε εδώ" onPress={() => alert('Κουμπί πατήθηκε!')} />


<ScrollView>
  <Text style={{ fontSize: 18 }}>Γραμμή 1SDSDSDSAD
    1SDSDSDSADSD
    1SDSDSDSADSAD
    1SDSDSDSADSDSAD
    1SDSDSDSADSADDS
    DS
    DSD
    1SDSDSDSADSDSADSAD
    1SDSDSDSADSDSADSADDS
    DSDSDSD
    ScrollViewDS
    DSDSDSDDS
    DSDSDSDDSDS
    DSDSDSDDSDSD
    1SDSDSDSADSDSADSADSD
    1SDSDSDSADSADDSDS
  </Text>
  
</ScrollView>

<View style={styles2.container}>
      <Text style={styles.box}>Box 1</Text>
      <Text style={styles.box}>Box 2</Text>
      <Text style={styles.box}>Box 3</Text>
    </View> 

<FlatList
      data={data}
      keyExtractor={item => item.idi}
      renderItem={({ item }) => (
        <View style={styles.container}>
          <Text style={styles.box}>{item.idi} {item.extra} {item.name}</Text>
        </View>      )}    />



    </View>  
    
  
  )};

    
const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    backgroundColor: 'lightblue',
    padding: 20,
    justifyContent: 'center',
    alignItems: 'center'  },
  text: {    fontSize: 20,
    fontWeight: 'bold',
    color: 'green'  },
    
    box: {
      flex: 1,
      flexDirection: 'column',
      justifyContent: 'space-between',
  
      padding: 20,
      margin: 10,
      backgroundColor: 'lightcoral',
      color: 'white',
      fontSize: 18  },
      container2: {
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'space-between'
      }
  
  });


  const styles2 = StyleSheet.create({
    container: {
      flex: 1,
      flexDirection: 'row',
      backgroundColor: 'lightblue',
      padding: 20,
      justifyContent: 'center',
      alignItems: 'center'  },

    });
    */

import Navigation from './Navigation';

export default function App() {
  return <Navigation />;
}
