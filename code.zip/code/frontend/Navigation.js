import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import HomeScreen from './screens/HomeScreen';
import DetailsScreen from './screens/DetailsScreen';
import DetailsScreen2 from './screens/DetailsScreen2';
const Stack = createStackNavigator();
export default function Navigation() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Home" component={HomeScreen} options={{ title: 'Αρχική' }} />
        <Stack.Screen name="Details" component={DetailsScreen} options={{ title: 'Λεπτομέρειες' }} />
        <Stack.Screen name="Details2" component={DetailsScreen2} options={{ title: 'Λεπτομέρειες2' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
