import React from 'react';
import { View, Text, Button } from 'react-native';

export default function HomeScreen({ navigation }) {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Καλώς ήρθατε στην εφαρμογή κρατήσεων!</Text>
      <Button title="Δείτε Εστιατόριο" onPress={() => navigation.navigate('Details', { name: 'Taverna Giannis' })} />
      <Button title="Δείτε Εστιατόριο2" onPress={() => navigation.navigate('Details2', { name: 'Taverna Manolis' })} />
    </View>
  );
}
