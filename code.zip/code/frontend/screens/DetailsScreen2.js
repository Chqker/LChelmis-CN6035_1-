import React from 'react';
import { View, Text } from 'react-native';
import axios from 'axios';

export default function DetailsScreen2({ route }) {


  axios.post('http://172.16.221.81:5000/users', {//to work in android emulator use the local IP
 
    username: 'John Doe',
    password:'1234',
    email: 'john@example.com'
  })
  .then(response => console.log('User created:', response.data))
  .catch(error => console.error('Error:', error));


  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Λεπτομέρειες 2  για το εστιατόριο: </Text>
    </View>
  );
}