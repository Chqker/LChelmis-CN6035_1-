import React from 'react';
import { View, Text } from 'react-native';

export default function DetailsScreen({ route }) {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Λεπτομέρειες για το εστιατόριο: {route.params.name}</Text>



      
    </View>
  );
}
