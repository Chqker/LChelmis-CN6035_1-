/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */
const mysql = require('mysql');

let getAllRest= (res) => {
    const connection = mysql.createConnection({
        host: 'localhost',
        user: 'root',
        password: '',
        database: 'nodejs'
        });
        connection.connect();
        const q = 'SELECT * from restaurants';
        connection.query(q, (err, rows, fields) => {
        //if (err) throw err;
        connection.end(); 
        let jsonarray = [];
        rows.forEach( function(element, index) {
    
            jsonarray.push({
      restId: element.restId,    // Name column (index 0)
      restDescription: element.restDescription    // Age column (index 1)
      
    });
           
  });
        //const e = JSON.stringify(jsonarray);
        console.log(jsonarray);
        //res.json(e);
        res.json(jsonarray);
        //return (myrows);
});

 
};

module.exports = { getAllRest };

