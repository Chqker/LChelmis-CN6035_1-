/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */

const express = require('express');
const jwt = require('jsonwebtoken');


const router = express.Router();
const mysql = require('mysql');



router.post('/', (req, res) =>{
    
    
    const { username, password } = req.body;
    console.log(username);
    
   
        const connection = mysql.createConnection({
        host: 'localhost',
        user: 'root',
        password: '',
        database: 'nodejs'
        });
        connection.connect();
        const q = "SELECT * from users where name ='"+ username+"' and password = '" + password +"'";
        console.log(q);
        connection.query(q, (err, rows, fields) => {
       // if (err) throw err;
        console.log(rows);
       
        if( rows.length !== 0     )
        {
            const user = {  username: username };
            //const token = jwt.sign(user, 'mysecretkey', { expiresIn: '1h' });
            //console.log(token);
            //res.json({ token });

            res.json({ message: "Login successful!" });
        }
        else 
        {
            res.json({ message: "Invalid credentials" });
        }
        // res.json(JSON.stringify(rows));
         //res.send(JSON.stringify(rows));
});

connection.end();
});

module.exports = router;

