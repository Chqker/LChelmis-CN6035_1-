/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */

const express = require('express');
 var userexists = true;
        const router = express.Router();
        const mysql = require('mysql');
        router.post('/', (req, res) => {


        const { username, password, email} = req.body;
                console.log(username);
                const connection = mysql.createConnection({
                host: 'localhost',
                        user: 'root',
                        password: '',
                        database: 'nodejs'
                });
                connection.connect();
                const q = "SELECT * from users where name ='" + username + "' ";
                console.log(q);
                connection.query(q, (err, rows, fields) => {
                // if (err) throw err;
                console.log(rows);
                if (rows.length !== 0)
                {
                 userexists = true;
                 //res.json({ message: "User already exists" });
                }
                else
                {
                userexists = false;
                }
                });
                console.log(userexists);
                if (userexists)
        {
        res.json({ message: "user already exists!" });
        }
        else
        {/*
        q = "insert into users (name, password, email) values ('" + username + "','" + password + "','" + email + "')";
                console.log(q);
                connection.query(q, function (err, result) {
                if (err) {
                // Throw your error output here.
                console.log("An error occurred." + err);
                } else {
                // Throw a success message here.
                console.log("1 record successfully inserted into db");
                }
                });
                res.json({ message: "Registration successful!" });
        */}

        
        connection.end();
        });
        module.exports = router;




