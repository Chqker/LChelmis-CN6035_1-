const express = require('express');
const router = express.Router();
const mysql = require('mysql');
router.get('/',  (req, res) =>{
// Handling GET / Request

    
    //res.send("All reservations with get");
    const connection = mysql.createConnection({
        host: 'localhost',
        user: 'root',
        password: '',
        database: 'nodejs'
        });
        connection.connect();
        const q = 'SELECT * from reservations';
        connection.query(q, (err, rows, fields) => {
        if (err) throw err;
        console.log(JSON.stringify(rows));
        res.json(JSON.stringify(rows));
       
});

connection.end();
});

router.get('/:reservationId',  (req, res) =>{
    const reservationId = req.params.reservationId;
    //res.send("One reservation with get" + reservationId);
        const connection = mysql.createConnection({
        host: 'localhost',
        user: 'root',
        password: '',
        database: 'nodejs'
        });
        connection.connect();
        const q = 'SELECT * from reservations where reservId ='+ reservationId;
        console.log(q);
        connection.query(q, (err, rows, fields) => {
        if (err) throw err;
        console.log(JSON.stringify(rows));
        res.json(JSON.stringify(rows));
        // res.json(rows);
});

connection.end();
});

module.exports = router;