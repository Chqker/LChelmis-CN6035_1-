const express = require('express');
const { getRest} = require('../controllers/restController');

const router = express.Router();
const mysql = require('mysql');
router.get('/',getRest ); 

router.get('/:restaurantId', (req, res) =>{
    const restaurantId = req.params.restaurantId;
    //res.send("One restaurant with get" + restaurantId);
        const connection = mysql.createConnection({
        host: 'localhost',
        user: 'root',
        password: '',
        database: 'nodejs'
        });
        connection.connect();
        const q = 'SELECT * from restaurants where restId ='+ restaurantId;
        console.log(q);
        connection.query(q, (err, rows, fields) => {
        if (err) throw err;
        console.log(JSON.stringify(rows));
         res.json(JSON.stringify(rows));
         //res.send(JSON.stringify(rows));
});

connection.end();
});

module.exports = router;