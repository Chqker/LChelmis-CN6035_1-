const express = require('express');
const restRoutes = require('./routes/restRoutes');
const reservRoutes = require('./routes/reservRoutes');
const loginRoutes = require('./routes/loginRoutes');
const registerRoutes = require('./routes/registerRoutes');
const users = require('./routes/users');

// Creating instance of express
const app = express();
const cors = require('cors');

app.use(express.json());
app.use(cors());
/*app.get('/', (req, res) => {
  
  res.json([{ "setup": "one","punchline":"two" },{ "setup": "one","punchline":"two" }]);
});*/

app.use('/restaurants', restRoutes);
app.use('/reservations', reservRoutes);
app.use ('/login', loginRoutes);
app.use ('/register', registerRoutes);
app.use ('/users', users);

app.listen(5000, function () {
    console.log("server started");
});