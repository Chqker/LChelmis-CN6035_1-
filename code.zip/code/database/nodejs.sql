-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 13, 2025 at 06:41 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nodejs`
--

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `reservId` int(11) NOT NULL,
  `restId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `reservPeople` int(11) NOT NULL,
  `reservDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`reservId`, `restId`, `userId`, `reservPeople`, `reservDate`) VALUES
(1, 1, 1, 5, '2025-03-12'),
(2, 2, 3, 3, '2025-03-13');

-- --------------------------------------------------------

--
-- Table structure for table `restaurants`
--

CREATE TABLE `restaurants` (
  `restId` int(11) NOT NULL,
  `restDescription` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `restaurants`
--

INSERT INTO `restaurants` (`restId`, `restDescription`) VALUES
(1, 'Souvlaki Andreas'),
(2, 'Tylichto Vouliagmeni'),
(3, 'McDonalds'),
(4, 'Goodys'),
(5, 'pizza fan'),
(10, 'tsoukali');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`name`, `password`, `email`) VALUES
('fotaras', '20', ''),
('orta', '3', ''),
('jaremtsouk', '1', ''),
('nun', '50', ''),
('ounai', '2', ''),
('lare', '20', ''),
('aaaa', '11111', 'aaaa'),
('sssss', 'sssss', 'sssss'),
('undefined', '1234', 'john@example.com'),
('John Doe', '1234', 'john@example.com'),
('John Doe', '1234', 'john@example.com'),
('fotaras', '20', 'undefined'),
('fotaras', '20', 'undefined');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`reservId`);

--
-- Indexes for table `restaurants`
--
ALTER TABLE `restaurants`
  ADD PRIMARY KEY (`restId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
